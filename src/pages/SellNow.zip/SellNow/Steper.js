import { ChakraProvider, extendTheme } from '@chakra-ui/react';
import { StepsStyleConfig as Steps } from 'chakra-ui-steps';
import About from './Productdetails/Productdetails';
import PersonalDetails from './Personaldetail/PersonalDetails';
import SteperForm from '../SellNow/Form';
import './Form.css';


const theme = extendTheme({
  components: {
    Steps,
  },
});

const Steper = () => {
  return (
    <ChakraProvider theme={theme}>
        <div className = 'Stepper'>
      <SteperForm className="stepperform"/>
      </div>
    </ChakraProvider>
  );
};

export default Steper;