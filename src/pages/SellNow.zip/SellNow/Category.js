import React from 'react'
import Cardscg from '../../components/Cardscg';
import { Step, Steps, useSteps } from "chakra-ui-steps"
import { Box  } from "@chakra-ui/react"
import './Category.css';

const Category = () => {


  return (
    <div>
        <Box w='100%' display="flex">                    
            <Box w='100%' className='cards1234' height={{
      base: '100%', // 0-48em
      md: '50%', // 48em-80em,
      xl: '25%', // 80em+
    }} >
            <h1>Luxury Watch</h1>
            </Box>
            <Box w='100%' className='cards1234' height={{
      base: '100%', // 0-48em
      md: '50%', // 48em-80em,
      xl: '25%', // 80em+
    }} >
            <h1>Luxury Bag</h1>
            </Box>
            <Box w='100%' className='cards1234' height={{
      base: '100%', // 0-48em
      md: '50%', // 48em-80em,
      xl: '25%', // 80em+
    }} >
            <h1>Electronics</h1>
            </Box>
            <Box w='100%' className='cards1234' height={{
      base: '100%', // 0-48em
      md: '50%', // 48em-80em,
      xl: '25%', // 80em+
    }} >
              <h1>Digit Assets</h1>
            </Box>
        </Box>
    </div>
  )
}

export default Category;