import React, { useState } from 'react'
import { Image } from "@chakra-ui/react"
import { Helmet } from 'react-helmet';
import { Checkbox, FormControl,Select,FormLabel,Box,Container,FormHelperText,FormErrorMessage } from '@chakra-ui/react'
import cover from './cover.jpg'
import { Input,InputGroup, InputLeftElement, Textarea,Button  } from "@chakra-ui/react"
import {BsEnvelope, GiPositionMarker, HiOutlinePhone} from 'react-icons/all'
import { FaArrowRight } from 'react-icons/fa';
import './personaldetails.css';

const PersonalDetails = () => {
    const [input, setInput] = useState('')

    const handleInputChange = (e) => setInput(e.target.value)
  
    const isError = input === ''
    return (

        <div className="personaldetails">
            <Helmet>
                <title>Contact</title>
            </Helmet>
        
        <div className='personalDetails'>
        <Container maxW='container.lg'>
            <Box display="flex"  w='100%'> 
               <Box w='100%' display="flex">
                    <Box mt={2}>
                    <FormLabel htmlFor='country'><h4>Name</h4></FormLabel>
                    </Box>
                    <Box>
                    <Input type="text" placeholder='Enter Your Full Name' />
                    </Box>
               </Box>

               <Box w='100%' display='flex'>
                    <Box mt={2}>
                    <FormLabel htmlFor='country'><h4>Email ID</h4></FormLabel>
                    </Box> 
                    <Box>
                    <Input type="email" placeholder='Enter Your Email ID' />
                    </Box>
               </Box>

               <Box w='100%' display='flex'>
                    <Box mt={2}>
                    <FormLabel><h4>Contact No</h4></FormLabel>
                    </Box>
                    <Box>
                    <Input type="number" placeholder='Enter Your Contact No' />
                    </Box> 
               </Box>
            </Box>
        </Container>

        <Container maxW='container.md' mt="3">
        
        <Box display='flex'>
            <Box w='100%' display='flex'>
                <Box mt={2}>
                <FormLabel htmlFor='country'><h4>Preferred Contact Time</h4></FormLabel>
                </Box>
                <Box>
                <Select id='country' placeholder='Select Time' style={{paddingRight:"90px"}}>
                <option>10-11 AM</option>
                <option>12-01 PM</option>
                </Select>
                </Box>
                <Box  ms={7}  mt={2}>
                    <FormLabel><h4>Message</h4></FormLabel>
                    </Box>
                    <Box>
                    <Textarea placeholder='Type Your Message' />
                    </Box>
            </Box>
            
        </Box>

        </Container>
   
        {/* <Button className='continue-btn'>
            <Box display="flex">
            <Box>Submit</Box>
            <Box ms={2}><FaArrowRight/>
            </Box>
            </Box>
        </Button>    */}

        </div>
        </div>
    )
}

export default PersonalDetails;
