import { Step, Steps, useSteps } from "chakra-ui-steps"
import { Flex, Button,Contents, Container,Heading } from '@chakra-ui/react'
import About from "./Productdetails/Productdetails"
import PersonalDetails from "./Personaldetail/PersonalDetails"
import Category from '../SellNow/Category';

// const steps = [
//   { label: "Category" },
//   { label: "Product Details" },
//   { label: "Personal Details" },
// ]

const Form = () => {
  const { nextStep, prevStep, reset, activeStep } = useSteps({
    initialStep: 0,
  })
  return (
    <Flex flexDir="column" width="100%">
      {/* <Container> */}
      <Steps labelOrientation="vertical" activeStep={activeStep}>
       
          <Step label={"Category"} key={1}>
           <Category/>
          </Step>
          <Step label={"Product Details"} key={2}>
            <About/>
          </Step>
          <Step label={"Personal Details"} key={3}>
            <PersonalDetails/>
          </Step>
     
      </Steps>
      {/* </Container> */}
      {activeStep === 3 ? (
        <Flex px={4} py={4} width="100%" flexDirection="column">
          <Heading fontSize="xl" textAlign="center">
            Thank You
          </Heading>
          <Button mx="auto" mt={6} size="sm" onClick={reset} >
            Sell Another Product
          </Button>
        </Flex>
      ) : (
        <Flex width="100%" justify="flex-end">
          <Button
            isDisabled={activeStep === 0}
            mr={4}
            onClick={prevStep}
            size="sm"
            variant="ghost"
            className="prev-btn"
          >
            Prev
          </Button>
          <Button size="sm" onClick={nextStep} className="next-btn">
            {activeStep === 3 - 1 ? "Finish" : "Next"}
          </Button>
        </Flex>
      )}
    </Flex>
  )
}

export default Form;