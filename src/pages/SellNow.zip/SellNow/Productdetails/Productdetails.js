import React,{useRef,useEffect, useState} from 'react'
import { Helmet } from 'react-helmet';
import {Container} from '@chakra-ui/react'
import HashLoader from "react-spinners/HashLoader";
import { FaArrowRight } from 'react-icons/fa';
import './Productdetails.css'
import { Checkbox, FormControl,Select,FormLabel,Textarea,Button,Box,Input } from '@chakra-ui/react'

const About = () => {
 
    const[brand , setBrand] = useState("")
    const[model , setModel] = useState("")
    const[ref , setRef] = useState("")
    const[year , setYear] = useState("")
    const[size , setSize] = useState("")
    
    return (   
        <>
        <Helmet>
            <title>Productdetails</title>
        </Helmet>

        <div className='productdetails'>
        <Container maxW='container.lg'>
            <Box  className='product-box'> 
               <Box w='100%' className='product-box'>
                {/* <FormControl> */}
                    <Box mt={2}>
                    <FormLabel htmlFor='country'><h4>Brand</h4></FormLabel>
                    </Box>
                    <Box>
                    <Select id='country' style={{paddingRight:"100px"}} placeholder='Select brand' 
                    onChange={e => setBrand(e.target.value)}
                    value={brand}>
                        <option>Puma</option>
                        <option>Zara</option>
                    </Select>
                    </Box>
                {/* </FormControl> */}
               </Box>

               <Box w='100%' className='product-box'>
                {/* <FormControl> */}
                    <Box mt={2}>
                    <FormLabel htmlFor='country'><h4>Model</h4></FormLabel>
                    </Box>
                    <Box>
                    <Select id='country' style={{paddingRight:"100px"}} placeholder='Select model'
                    onChange={e => setModel(e.target.value)}
                    value={model}>
                        <option>1</option>
                        <option>2</option>
                    </Select>
                    </Box>               
                {/* </FormControl> */}
               </Box>

               <Box w='100%' className='product-box'>
                    <Box>
                    <FormLabel style={{width:"88px"}} className="ref-nos"><h4>Reference Model no</h4></FormLabel>
                    </Box>
                    <Box>
                    <Input type="number" placeholder='Enter Reference Model No.' className='ref-no'
                    onChange={e => setRef(e.target.value)}
                    value={ref} />
                    </Box> 
               </Box>
            </Box>
        </Container>

        <Container maxW='container.md'>
        {/* <FormControl> */}
        {/* <Box> */}
        <Box display='flex'>
            <Box w='100%' display='flex'>
                <Box mt={2}>
                <FormLabel htmlFor='country'><h4>Select Year</h4></FormLabel>
                </Box>
                <Box>
                <Select id='country' placeholder='Select year' style={{paddingRight:"100px"}}
                 onChange={e => setYear(e.target.value)}
                 value={year}>
                <option>2021</option>
                <option>2022</option>
                </Select>
                </Box>
            </Box>
            <Box w='100%' display='flex'>
                <Box mt={2}>
                <FormLabel><h4>Size</h4></FormLabel>
                </Box>
                <Box>
                <Input type="text" placeholder='Enter Size'
                onChange={e => setSize(e.target.value)}
                value={size} />
                </Box>  
            </Box>
        </Box>
        {/* </FormControl> */}
        </Container>

        {/* <Container maxW='container.md' mt="10">
            <Box>
            <div class="slidecontainer">
                <input type="range" min="1" max="100" value="50" class="slider" id="myRange"/>
            </div>
            </Box>
        </Container> */}

        <Container maxW='container.md'>
            <Box w='100%' display='flex'>
                <Box w='100%' display='flex'>
                    <Box>
                    <FormLabel><h4>Accessories</h4></FormLabel>
                    </Box>
                    <Box style={{marginLeft:"10px"}}>
                    <Checkbox >Box</Checkbox><br/>
                    <Checkbox >Bill</Checkbox><br/>
                    <Checkbox >Paper/Warrenty Card</Checkbox>
                    </Box>    
                </Box>
                <Box w='100%' display='flex'>
                    <Box>
                    <FormLabel><h4>Add Description</h4></FormLabel>
                    </Box>
                    <Box>
                    <Textarea placeholder='Add Description' />
                    </Box>
                </Box>
            </Box>
        </Container>

        <Container maxW='container.md'>
            <Box w='100%' display='flex'>
                <Box w='100%' display='flex'>
                    <Box mt={3}>
                    <FormLabel><h4>Upload Bills</h4></FormLabel>
                    </Box>
                    <Box className='file-upload'>
                    <input type="file" id="myFile" name="filename"/>
                    </Box>

                    <Box mt={3} ms={8}>
                    <FormLabel><h4>Upload Images</h4></FormLabel>
                    </Box>
                    <Box className='file-upload'>
                    <input type="file" id="myFile" name="filename"/>
                    </Box>                   
                </Box>
            </Box>
        </Container>
            
        <Container maxW='container.lg' mt={8}>
            <Checkbox className='checkboxx'><h5 style={{fontSize:"16px" , textAlign:"center"}}>CLICK HERE TO AGREE TO OUR <span style={{color:"blue" ,fontWeight:"bold"}}>PRIVACY POLICY, TERMS & CONDITIONS</span> AND RECEIVE OUR NOTIFICATIONS</h5></Checkbox>
        </Container>
            
        {/* <Button className='continue-btn' onClick={e => { 
        e.preventDefault();
        // alert();
        console.log({brand,model,ref,year,size});
        }}
        >
            <Box display="flex">
            <Box>Continue</Box>
            <Box ms={2}><FaArrowRight/>
            </Box>
            </Box>
        </Button> */}

        </div>
        </>
    
    )
}

export default About
